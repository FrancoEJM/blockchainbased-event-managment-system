import Navbar from "../../components/Navbar";
import EventWizard from "../../components/CreateEvent/EventWizard";

function CreateEvent() {
  return (
    <div>
      <Navbar />
      <EventWizard />
    </div>
  );
}
export default CreateEvent;
