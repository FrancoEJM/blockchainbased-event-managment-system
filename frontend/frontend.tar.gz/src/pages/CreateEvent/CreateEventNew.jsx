import EventWizardNew from "../../components/CreateEvent/EventWizardNew";
import NavbarTest from "../../components/NavbarTest";

function CreateEventNew() {
  return (
    <>
      <NavbarTest />
      <EventWizardNew />
    </>
  );
}
export default CreateEventNew;
