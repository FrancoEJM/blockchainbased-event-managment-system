import LoginLayout from "../../components/Login/LoginLayout";

function Login() {
  return <LoginLayout />;
}

export default Login;
