import NavbarTest from "../../components/NavbarTest";
import EventsGeneralStats from "../../components/Events/EventsGeneralStats";
function EventGeneralStats() {
  return (
    <>
      <NavbarTest />
      <EventsGeneralStats />
    </>
  );
}
export default EventGeneralStats;
