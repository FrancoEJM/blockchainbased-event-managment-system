import EventsList from "../../components/Events/EventsList";
import Navbar from "../../components/Navbar";
function Events() {
  return (
    <div>
      <Navbar />
      <EventsList />
    </div>
  );
}
export default Events;
