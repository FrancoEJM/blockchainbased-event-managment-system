import EventDisplayStats from "../../components/Events/EventDisplayStats";
import NavbarTest from "../../components/NavbarTest";
function EventStats() {
  return (
    <>
      <NavbarTest />
      <EventDisplayStats />
    </>
  );
}
export default EventStats;
